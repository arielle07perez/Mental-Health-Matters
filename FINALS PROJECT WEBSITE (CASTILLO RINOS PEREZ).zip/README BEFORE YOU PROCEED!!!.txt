-NOTE!!!-

Before you proceed, the main file can be found inside of the folder "project.html" where all files are
all there connected to the main root of the "project.html". Please download it for checking. Thank you 
and have a nice day.

Contributors: (BS1MA Students)
Castillo, Dawn Xyly B.
Rinos, Marlon
Perez, Princess Arielle